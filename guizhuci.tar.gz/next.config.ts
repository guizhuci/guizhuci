import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Vercel 部署，使用默认配置（支持全栈）
};

export default nextConfig;
